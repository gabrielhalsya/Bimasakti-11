﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class TransCodeDTO : R_APIResultBaseDTO
    {
        public bool LINCREMENT_FLAG { get; set; }
        public bool LAPPROVAL_FLAG { get; set; }
    }
}
