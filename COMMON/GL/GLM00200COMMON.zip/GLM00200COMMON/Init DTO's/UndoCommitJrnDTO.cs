﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class UndoCommitJrnDTO 
    {
        public Int32 IOPTON { get; set; }

    }
}
