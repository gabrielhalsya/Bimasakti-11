﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class TodayDTO
    {
        public DateTime DTODAY { get; set; }
    }
}
