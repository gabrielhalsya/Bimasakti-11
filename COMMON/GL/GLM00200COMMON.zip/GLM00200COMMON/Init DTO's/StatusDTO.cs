﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class StatusDTO
    {
        public string CCODE { get; set; }
        public string CNAME { get; set; }
    }
}
