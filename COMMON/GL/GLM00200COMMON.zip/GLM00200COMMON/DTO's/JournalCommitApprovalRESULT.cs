﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class JournalCommitApprovalRESULT : R_APIResultBaseDTO
    {
        public int RESULT { get; set; }
    }
}
