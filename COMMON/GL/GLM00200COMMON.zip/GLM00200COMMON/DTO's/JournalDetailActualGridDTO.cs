﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class JournalDetailActualGridDTO
    {
        public string CREF_NO { get; set; }
        public string CDOC_SEQ_NO { get; set; }
        public string CREF_PRD { get; set; }
        public string CREF_DATE { get; set; }
        public string NTRANS_AMOUNT { get; set; }
        public string NLTRANS_AMOUNT { get; set; }
        public string NBTRANS_AMOUNT { get; set; }
        public string CCREATE_BY { get; set; }
        public string DCREATE_DATE { get; set; }
    }
}
