﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLM00200Common
{
    public class CurrencyRateParamDTO : CurrencyRateResult
    {
        public string CCOMPANY_ID { get; set; }   
        public string CSTART_DATE { get; set; }
    }
}
