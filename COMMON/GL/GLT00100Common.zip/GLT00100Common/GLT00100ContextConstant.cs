﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common
{
    public class GLT00100ContextConstant
    {
        public const string CPERIOD = "CPERIOD";
        public const string CSEARCH_TEXT = "CSEARCH_TEXT";
        public const string CREC_ID = "CREC_ID";
        public const string CDEPT_CODE = "CDEPT_CODE";
        public const string CREF_NO = "CREF_NO";
        public const string LSelected = "LSelected";
        public const string CTRANS_CODE = "CTRANS_CODE";
        public const string CSTATUS = "CSTATUS";
    }
}
