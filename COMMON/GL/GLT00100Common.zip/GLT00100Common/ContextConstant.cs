﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common
{
    public class ContextConstant
    {
        public const string CSTATUS = "CSTATUS";
        public const string CDEPT_CODE = "CDEPT_CODE";
        public const string CREC_ID = "CREC_ID";
        public const string CPERIOD = "CPERIOD";
        public const string CSEARCH_TEXT = "CSEARCH_TEXT";
    }
}
