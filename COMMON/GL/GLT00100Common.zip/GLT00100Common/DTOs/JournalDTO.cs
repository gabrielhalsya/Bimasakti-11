﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common.DTOs
{

    //public class JournalDTO : GLT00100DTO
    //{
    //    public List<GLT00100JournalGridDetailDTO> ListJournalDetail { get; set; }

    //}
}

