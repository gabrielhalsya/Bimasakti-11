﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common.DTOs
{
    public class SelectedDTO : GLT00100DTO
    {
        public bool LSelected { get; set; }

    }
}
