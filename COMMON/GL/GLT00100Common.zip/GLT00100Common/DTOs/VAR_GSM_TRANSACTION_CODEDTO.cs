﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common.DTOs
{
    public class VAR_GSM_TRANSACTION_CODEDTO : R_APIResultBaseDTO
    {
        public bool LINCREMENT_FLAG { get; set; }
        public bool LAPPROVAL_FLAG { get; set; }
    }
}
