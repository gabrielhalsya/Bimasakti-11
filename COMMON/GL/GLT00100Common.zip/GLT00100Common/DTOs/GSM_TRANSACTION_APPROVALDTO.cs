﻿using System;
using System.Collections.Generic;
using System.Text;
using R_APICommonDTO;

namespace GLT00100Common.DTOs
{
    public class GSM_TRANSACTION_APPROVALDTO :R_APIResultBaseDTO
    {
        public string CRESULT {get; set; }
    }
}
