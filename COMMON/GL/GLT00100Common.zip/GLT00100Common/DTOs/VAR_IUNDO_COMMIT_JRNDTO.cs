﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common.DTOs
{
    public class VAR_IUNDO_COMMIT_JRNDTO : R_APIResultBaseDTO
    {
        public int IOPTION { get; set; }
    }
}
