﻿using R_APICommonDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common.DTOs
{
    public class VAR_CSOFT_PERIOD_START_DATEDTO : R_APIResultBaseDTO
    {
        public string CSTART_DATE { get; set; }
    }
}
