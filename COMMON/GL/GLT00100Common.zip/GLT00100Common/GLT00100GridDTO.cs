﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GLT00100Common
{
    public class GLT00100GridDTO : GLT00100DTO
    {
        public Decimal NNTRANS_AMOUNT_C { get; set; }
    }
}
